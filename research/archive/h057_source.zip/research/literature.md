# Initial prior-work audit â€” 2026-09-06

Primary sources checked; this is not exhaustive novelty certification.
Author-reported results are not reproduced here. Follow-up ideas are our inferences.

| Source | Mechanism / evidence | Cost, limitation and consequence |
|---|---|---|
| [GLU variants](https://arxiv.org/abs/2002.05202) | Multiplicative projected features improve Transformer results | Three matrices; use 2/3 width for parameter matching |
| [KAN](https://arxiv.org/abs/2404.19756) | Learned edge splines; small function-fitting/scientific examples | Edge functions cost memory and compute; toy wins are not LM proof |
| [KAT / Group KAN](https://arxiv.org/abs/2409.10594) | Shared rational functions, CUDA evaluation, variance-aware initialization | Group sharing already exists; vision results do not prove our LM target |
| [PadÃ© Activation Units](https://arxiv.org/abs/1907.06732) | Trainable rational activations | Denominator safety/evaluation costs; strong future activation control |
| [Adaptive piecewise-linear activations](https://arxiv.org/abs/1412.6830) | Learned hinge combinations | More knots cost work; learned shape itself is prior art |
| [Learnable polynomial/trigonometric/tropical activations](https://arxiv.org/abs/2502.01247) | Learned bases tested on ImageNet/OpenWebText | Initialization and basis evaluation matter; basis mixtures already studied |
| [Learning polynomial activation functions](https://arxiv.org/abs/2510.03682) | Polynomial optimization treatment | Specialized optimization is not evidence of fast GPU LM training |
| [Low-rank Transformer training](https://arxiv.org/abs/2407.09835) | From-scratch low-rank models up to 1.3B | Rank and throughput tradeoffs; indispensable control for future low-rank claims |
| [Structured feedforward layers](https://openreview.net/pdf?id=WxLVYZbIew) | Low-rank/block-diagonal FFNs from scratch | Some comparisons change attention too; our attention stays fixed |
| [Monarch](https://arxiv.org/abs/2204.00595) | Products of structured block matrices | Restricted structure and kernel costs; alternative to input bottlenecks |
| [ALBERT](https://arxiv.org/abs/1909.11942) | Parameter sharing and embedding factorization | Fewer weights do not imply less compute; time recurrence |
| [BitNet b1.58](https://arxiv.org/abs/2402.17764) | Ternary weights | Storage reduction differs from fewer learned parameters |
| [Sparse MoE](https://arxiv.org/abs/1701.06538) | Conditional specialist execution | Active compute can be low while total parameter count is high |
| [TinyStories](https://arxiv.org/abs/2305.07759) | Small-model language learning | Narrow synthetic distribution; screening only |
| [FineWeb](https://arxiv.org/abs/2406.17557) | Curated general web corpus | Broader, more expensive evaluation for finalists |

No verified source here establishes our exact bounded cubic residual at 75% FFN
reduction as useful. Absence in a search is not proof of novelty. Expand BÃ©zier,
Bernstein-network and coordinate-dependent basis searches before publication,
and reproduce practical rational/structured baselines. Our bank-collapse and
bottleneck proofs are elementary structural observations without priority claims.


## Additional comparisons checked during branching

- [Structured FFNs, Wei et al.](https://arxiv.org/abs/2406.16450) and their
  [official code](https://github.com/CLAIRE-Labo/StructuredFFN): block-structured
  projections, self-guided training and separate decoding optimizations. Our
  simple grouped sandwich is a related control, not their exact reproduction.
- [Flash Multi-Head FFN](https://arxiv.org/abs/2512.06989): a current relevant
  efficient-FFN comparator. Its reported kernel/memory gains must not be
  attributed to our eager grouped implementation; full method review remains.
- [KANs for Small Language Models, Alves and Vicente](https://arxiv.org/abs/2607.15525):
  reports inconsistent downstream/scaling benefits of the tested learned-function
  replacements against strong MLP/SwiGLU baselines. This supports caution, not a
  claim that our specific negative result proves all KANs fail.
- [One Wide Feedforward Is All You Need](https://arxiv.org/abs/2309.01826): FFN
  redundancy and sharing are direct prior art. Their encoder/decoder changes
  differ from our fixed decoder-only attention experiment.
- [Relaxed Recursive Transformers](https://arxiv.org/abs/2410.20672): layer-wise
  LoRA relaxes weight tying. It is a required comparator if we claim a new benefit
  from depth-specific adaptation of shared transformations.
- [FiLM](https://arxiv.org/abs/1709.07871): feature-wise affine conditioning is
  established. Any proposed per-layer scale/shift adaptation must acknowledge it.
- [MAXIM](https://arxiv.org/abs/2201.02973): cross-gating of feature streams exists
  in vision. A cross-group gate is not new merely because it uses that phrase.

Novelty remains unproven. We are establishing serious baselines and identifying
which mechanisms deserve original follow-up, rather than labeling prior art a
breakthrough.


## Follow-up structured-layer implementation audit
[Compute Better Spent](https://arxiv.org/abs/2406.06248) introduces Block Tensor-Train
layers and emphasizes architecture-dependent initialization and learning-rate
scaling. This is an additional required prior-work control for future structured
claims. The [StructuredFFN official code](https://github.com/CLAIRE-Labo/StructuredFFN)
distinguishes BlockShuffle (two block-diagonal factors) from BlockDense and
LowRank. Our current single-factor grouped controls are not a reproduction of
those stronger structured families. Their self-guided training also changes the
training computation and must be budgeted explicitly if implemented here.


The new `src/blockshuffle_ffn` now implements the two-factor BlockShuffle
control, with semi-orthogonal factor initialization and the declared fan-in
optimizer treatment. It compresses all FFNs in our fixed micro-decoder; it
does not reproduce the papers' scales, data, dense first FFN or optional
self-guided training. Read [the measured three-seed comparison](blockshuffle_results.md).


The [current comparator audit](current_comparator_audit.md) now records an
equation-level reading of FlashMHF and a derived near-matched parameter budget.
Its empirical comparison is still outstanding.
