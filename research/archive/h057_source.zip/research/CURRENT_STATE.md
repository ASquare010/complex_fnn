# Current research state - 2026-09-07

**The full goal remains unmet.** The [three-seed 3,200-step replication](long_duration_replication_results.md)
fails the original quality target. Plain BlockShuffle retains **70.3125% fewer
FFN weights**, but mean NLL is **4.147443**, **1.256% above full SwiGLU**.
Seed 43 also loses to calibrated narrow. The earlier 800-step advantage is
real at that budget and cannot be promoted to robust longer-training superiority.
All twelve longer runs continue improving at the end; convergence is unproven.

The requested six learnable-activation variants are implemented. Their strongest
simple affine correction gives only **0.101%** mean benefit at the same rate,
with wins in 2/3 seeds, so its material-improvement gate fails. A new, scoped
[input-Hessian proof](headwise_hessian_obstruction.md) explains a single headwise
layer limitation that arbitrary learned scalar shapes cannot remove. No novelty,
universal-optimality or whole-Transformer conclusion follows.

The completed [H052 factor-decay control](duration_decay_results.md) also fails.
Product decay reaches seed-17 NLL **4.152418**, **0.161% worse** than parameter
decay and **1.145% above full SwiGLU**. It misses both the local full-SwiGLU
allowance and the separate 0.2% improvement rule. Clipping increases from 30.50%
to 42.41%, with the same 714.12 MiB training allocation. The intermediate NLL
advantage reverses at the frozen endpoint. No further product-decay tuning is
earned by this cell; the smaller H013 negative result remains.

The new [H053 overcomplete structured-headwise module](overcomplete_qualification_results.md)
passes its explicit constrained-factor representation, FP64 derivatives,
isometric/covariance-scale initialization and native BF16 checks. It matches
350,208 weights/layer but has **20.37% higher isolated eager forward/backward
allocation** than full SwiGLU. The subsequent [H054 integration](overcomplete_integration_results.md) registers
it while preserving all 31 older model signatures. Complete-model native peak
730.389 MiB is 10.647% above full GELU 660.108 MiB, missing its memory allowance
by 4.270 MiB. All 20 fixed-batch updates per cell stay finite, but no language
quality screen is earned. The three cells use 122,880 repeated training-token
exposures and score no validation targets.

The completed [H055 native gate-recomputation control](overcomplete_recompute_results.md)
reduces the candidate's complete-model peak to **680.014 MiB**, **6.897% below
eager**, passing both full-control memory limits. It adds no parameters or new
activation. Initial BF16 parameter gradients and the entire 20-step repeated-batch
trajectory, including all 9,099,648 final weights, match eager exactly in this
qualification. This earned H056's balanced language-quality screen.

The completed [H056 quality screen](overcomplete_screen_results.md) **fails**.
The best of three rates reaches NLL **6.043891**, **2.305% above full SwiGLU**,
**2.800% above full GELU** and **2.223% above calibrated narrow**. It also loses
selected plain BlockShuffle by 1.227% and square headwise by 0.375%. Actual
training peak **676.931 MiB** passes both full memory gates. All three trials
remain finite, using 1,228,800 new sampled training tokens; no official test
is scored. The recipe is eliminated from promotion at this budget, while its
constructive representation result remains valid. The selected candidate's
layer-0 FFN output RMS grows from .012844 to 13.7203 versus full SwiGLU 3.8765.
Later FFN parameter-gradient norms are smaller, but these observations do not
prove vanishing gradients or explain the quality gap causally.

The completed [H057 checkpoint diagnosis](residual_geometry_results.md) establishes
local RMSNorm scale effects and an exact value/down rescaling symmetry, but
**does not establish the cause of H056's quality gap**. On native BF16 probes,
the candidate's later local gain is .7071 times full SwiGLU and .7742 times
narrow; full GELU has still lower gain and better NLL. Lower-rate candidates
have larger gains and better factor conditioning but worse NLL. In a disposable
copy, value *=8/down /=8 changes the corresponding gradient norms by 1/8 and 8
with zero measured logit/loss/gradient prediction error. This diagnosis branch
is finished; it earns no normalization or optimizer repair. All 248 tests pass.

The next distinct [H058 additive block/global proposal](additive_block_lowrank_proposal.md)
retains ordinary h=1024 SwiGLU and sums an eight-block map with a rank-48 global
map in each projection. Its analytical count is exactly 350,208 weights/layer,
matching the existing compressed controls. Sparse-plus-low-rank is established
prior art; this proposal is unimplemented and unqualified, with no novelty or
quality claim. Its primary-method audit, initialization and independent module
qualification must precede any language training.

## Latest controlled result: 3,200 steps

All recipes use d=384, eight layers, context 128, batch 16, vocabulary 4096,
peak LR 0.0012 and native BF16. Every model trains 6,553,600 sampled tokens and
scores all 322,688 validation targets. Means/sample SD use seeds 17/29/43.

| Recipe | NLL mean +/- SD | FFN weights | Maximum allocated training peak MiB |
|---|---:|---:|---:|
| Full SwiGLU | 4.095997 +/- .012345 | 9,437,184 | 702.19 |
| Full GELU | 4.121190 +/- .006266 | 9,437,184 | 656.62 |
| Calibrated narrow | 4.153498 +/- .012386 | 2,801,664 | 516.28 |
| Plain BlockShuffle | 4.147443 +/- .007315 | 2,801,664 | 714.12 |

| Seed | Plain NLL vs full SwiGLU | vs full GELU | vs narrow | Primary gates |
|---|---:|---:|---:|---|
| 17 | +0.9819% | +0.4323% | -0.1763% | PASS |
| 29 | +0.9898% | +0.6240% | -0.5992% | PASS |
| 43 | +1.7992% | +0.8552% | +0.3409% | FAIL |

Positive NLL difference is worse. Every seed must individually pass; averaging
cannot rescue seed 43's two failed gates. Mean advantage over narrow is only
0.1458%, below the separate 0.2% margin. Plain loses NLL to both full controls
in every seed. These are NLL engineering gates, not universal significance claims.
The report retains paired differences and exploratory small-sample intervals.

[H050](long_duration_results.md) trained the first four models; [H051](long_duration_replication_results.md)
adds eight independent-seed trials. Their allocations total 78,643,200 sampled
tokens. All completed with finite diagnostics and exact source/data/checkpoint/
CUDA-sampler verification. Their last 800 steps still improve NLL by 2.2%-2.9%,
failing every late-plateau diagnostic. The rate was selected at 800 steps;
a longer-duration optimum is not established. No paired training-speed claim
is made from cross-session throughput.

## Earlier corrected 800-step evidence

The same dimensions and peak LR 0.0012, but 800 steps and 1,638,400 training tokens:

| Recipe | NLL mean +/- SD | FFN weights |
|---|---:|---:|
| Full SwiGLU | 4.900513 +/- .017570 | 9,437,184 |
| Full GELU | 4.865926 +/- .005095 | 9,437,184 |
| Calibrated narrow | 4.877761 +/- .017970 | 2,801,664 |
| Plain BlockShuffle | 4.759029 +/- .010381 | 2,801,664 |
| BlockShuffle + affine activation | 4.754207 +/- .003945 | 2,801,792 |

The [corrected three-seed result](affine_rate_replication_results.md) gives plain
2.887% lower NLL than full SwiGLU and 2.197% lower than full GELU, with all
local gates passing. The [four-rate seed-17 grid](optimizer_lower_results.md)
keeps every recipe at an interior LR 0.0012. This is a discrete 800-step bracket,
not a rate ranking across seeds or durations. The
[retained configuration](../configs/wikitext2_blockshuffle_stronger_800.json)
reproduces that shorter recipe.

H041's apparent 1.755% affine gain compared different rates: plain 0.0006 and
affine 0.0012. [H043](affine_activation_rate_control_results.md) and
[H044](affine_rate_replication_results.md) correct that confound. At the stronger
common rate, affine helps only 0.101% and wins 2/3 seeds. The paired exploratory
95% interval crosses zero. Plain uses native custom gate backward; affine uses
checkpointed native autograd, another disclosed execution difference.

## Learnable activations, interaction proofs and negative controls

The [domain guide](learnable_activation_domain.md) explains shifted Bezier banks,
rational residuals and the 128-weight affine correction on narrow/BlockShuffle.
The [origin-Jacobian proof](../src/learnable_activation_ffn/model.md) gives a strict
extension of an isolated bias-free SwiGLU family, without a training guarantee.
[Removing the trained affine correction](affine_activation_removal_results.md)
costs less than 0.020% NLL in all three checkpoints. This measures final-checkpoint
dependence, not the cause of training differences.

Shifted Bezier and quadratic variants failed promotion. Native rational improves
selected short-screen quality but fails memory. Both the
[whole-product](activation_training_repeat_results.md) and
[correction-only](activation_correction_repeat_results.md) compiler routes passed
local derivative checks and failed full training repeats. All failures remain.

The [square-mixer Hessian witness](headwise_hessian_obstruction.md) strengthens
the fixed-coordinate argument: three particular vector-quadratic outputs cannot
share any nontrivial additive head partition after arbitrary learned square
mixing. Ordinary full SwiGLU represents them with 2*(d+1) hidden units. CPU
forward checks at d=3/6/24/384 and input-Hessian checks at d=3/6 pass. This is a
single-module exact-representability result; it proves no LM-loss bound,
value-only approximation gap, whole-network limitation or novelty. Function
and block decoupling are established prior art.

The [structured square-mixer budget](structured_headwise_budget.md) remains an
unimplemented analytical proposal inside that obstruction. The [overcomplete
alternative](../src/multihead_ffn/overcomplete.md) is now registered and trained
at the same 2,801,664 FFN-weight budget. H053 gives an explicit constrained-factor
representation of the excluded quadratic; H056 fails language quality. Neither
result proves whole-Transformer dominance or novelty.

## Other retained research evidence

[Parallel multi-head controls](multihead_screen_results.md) fail the local
200-step quality and memory gates. The [router-free headwise control](headwise_screen_results.md)
saves 23.3% of parallel allocated training memory but also fails quality at the
same BlockShuffle budget. These tiny-head adaptations do not refute published
larger-scale FlashMHF results; no FlashMHF kernel is implemented.

The [larger TinyStories three-seed study](scale_replication_results.md) and
[separate validation tail](validation_tail_results.md) pass local quality/memory
gates. The smaller d=192 result misses the <=1% NLL target. The
[four-kernel inference study](fused_execution_results.md) on a TinyStories seed-17
checkpoint measures median 1.206x throughput versus equally compiled full SwiGLU
at batch 16/context 128 BF16 on the RTX 4070 Laptop, with 144.15 versus 169.08 MiB
allocation. This is full-sequence inference, not training, generation or a
WikiText timing result. [Projection conditioning](joint_conditioning_results.md)
controls selected factor condition numbers, not a whole-network gradient bound.

The [CPU duration diagnosis](duration_optimizer_geometry.md) verifies eight
seed-17 short/long checkpoints. Accumulated factor decay increases markedly,
but inspected trained down-map Frobenius norms remain over twelve times
initialization. Do not report decay-only algebra as observed weight collapse
or a causal explanation. Spectral conditioning and optimization remain separate.

## Verification and runtime records

- **248 tests pass** in the [recorded full suite](../results/verification/residual_geometry_tests_v1.json),
  with `-p no:anyio`; all assertions and GPU checks remain enabled.
- The **32-model exact-signature evidence** remains valid; H056 changes no existing computation. There are **32 registered
  variants**, 11 architecture folders and **168 retained LM/profile runs**:
  86 at 200 steps, 66 at 800, 13 at 3,200 and 3 at 20. Separate qualifications,
  sampler reconstructions and CPU analyses are not counted as LM runs.
- H050/H051 change no NN, trainer, data, optimizer or diagnostic computation.
  H052 changes only the existing decay configuration; its six focused tests and
  full 235-test suite pass. One new 6,553,600-token trial completes without
  numerical or process failures. Its [plot](../results/plots/duration_decay.svg)
  and five endpoint records are verified.
  The [operational worker qualification](../results/long_duration_replication_v1/worker_transport_qualification_v1.json)
  dispatches identical frozen configurations directly to the unchanged trainer,
  avoiding plotting/report imports. Four tamper/overwrite checks pass.
- H051 retained two pre-training import failures; its qualified continuation
  completed all eight trials without numerical failures. Earlier optional
  compiler, plugin and later figure-regeneration import failures are retained.
  A post-test palette correction changes only plotting; the verified report's
  metric/decision code stays exact. Its [isolated plotting record](../results/verification/long_duration_replication_plot_verification_v1.json)
  verifies all twelve input records and preserves the earlier figures. The
  intermittent native/runtime root cause remains unresolved.
- Source archives, metric/checkpoint hashes, exact token streams, environment,
  optimizer metadata, clipping and layer diagnostics remain available. Official
  test remains unscored. No GPU training cohort is currently running.

## Next requirements

Stop the H057 diagnosis branch. It establishes local identities and contradictory
controls, not a sufficient cause of H056's loss gap. Do not use raw parameter-
gradient norms or composed-matrix conditioning as an automatic training remedy.
The overcomplete candidate remains rejected at its tested quality budget.

Proceed to the distinct H058 additive block/global mechanism: audit its primary
prior art and implementation conventions, derive one fixed initialization and
optimizer policy, then implement and numerically qualify the actual structured
module. The proposal matches the existing parameter budget but proves no
language advantage. It must earn complete-model memory and balanced screening.
Do not substitute a novelty claim for testing a known-family comparator.

The isolated product-decay explanation also failed. Larger scale, stronger
external comparators/data, verified novelty, convergence, multiple seeds and
scoped stability evidence remain open. Use uv, retain every negative outcome,
and run one bounded GPU experiment at a time.

H053 verification: 238 tests pass, with unchanged model/trainer/data computation
for every registered variant. The qualification driver has one recorded
lambda-to-equivalent-local-function style cleanup after the suite; its witness,
calibration and model code are unchanged. Exact original source is archived.

H054 verification: 241 tests pass. The saved 31-model CPU signature is exact after
registration; every new layer matches the qualified initializer. Three fresh
20-update complete-Transformer qualifications complete without numerical or
process failures. Their failed eager memory gate remains authoritative.

H055 verification: 243 tests pass and all 32 default model signatures remain
exact. One new 20-update recomputation cell uses 40,960 repeated training-token
exposures and zero validation targets. Both memory gates pass, with eager
trajectory equality verified for all final weights. No GPU cell is live.

H056 verification: 245 tests pass with all tested sources exact. The corrected
preflight verifies fifteen retained controls, exact validation/sampler streams,
actual optimizer groups and equivalent diagnostic values on a CPU probe. The
first preflight's overstrict diagnostic-byte assertion failed before training;
its log and original source are retained. The correction changes no model,
training, plan or selection gate. All three GPU trials complete first attempt.
The [report](overcomplete_screen_results.md) and [figure](../results/plots/overcomplete_screen.svg)
retain the failed quality gates. No GPU cell is live.

H057 verification: 248 tests pass and existing computation/configurations remain
unchanged. Fourteen CPU probes, six native BF16 probes and one disposable gauge
check make zero optimizer updates and score no validation/test targets. All 340
local norm VJPs match the independent formula within 9.882e-8 relative L2. All
phases finish first attempt; no GPU cell is live. The report retains all source,
checkpoint, cache and probe identities and the contradictory gain/NLL ordering.
