# Parameter-efficient FFN research

Plain BlockShuffle uses **70.3125% fewer FFN weights**, but it **does not meet
the longer-training research target**. The completed
[three-seed 3,200-step comparison](research/long_duration_replication_results.md)
gives mean NLL **4.147443**, **1.256% above full SwiGLU**. Seeds 17/29 pass the
local gates narrowly; seed 43 exceeds the 1% NLL allowance and loses to calibrated
narrow. All models are still improving at the final interval. No breakthrough,
converged superiority or verified new primitive is established.

The latest [isolated factor-decay control](research/duration_decay_results.md)
also fails: product decay gives seed-17 NLL **4.152418**, 0.161% worse than the
retained parameter-decay run and 1.145% above full SwiGLU. Clipping rises from
30.50% to 42.41%. The complete [trajectory](results/plots/duration_decay.svg)
shows that its interim advantage reverses by the frozen endpoint. No extra
product-decay tuning is earned; all source/data/sampler checks pass.

The earlier [800-step comparison](research/affine_rate_replication_results.md)
remains a valid shorter-budget result: plain mean NLL **4.759029** across three
seeds, 2.89% below full SwiGLU and 2.20% below full GELU, with all local gates
passing. Its advantage does not persist robustly when training is extended.

The requested learnable activations are implemented on both compressed bases:
shifted Bezier banks, rational residuals and a tiny affine correction
`SiLU(z) + a*z + b`. They learn group-shared shapes from the task loss. They
adapt to training data; no activation family is optimal for arbitrary data.
The [domain guide](research/learnable_activation_domain.md) and
[model proofs](src/learnable_activation_ffn/model.md) explain the equations,
expressivity, gradient bounds and limits.

The affine recipe adds only **128 weights** and achieves mean NLL **4.754207**.
However, its apparent 1.755% advantage over the earlier plain recipe compared
different learning rates. At the **same rate**, its mean gain is only **0.101%**,
with wins in 2/3 seeds; it fails the frozen material-improvement gate. The
[same-rate control](research/affine_activation_rate_control_results.md) and
[independent-seed correction](research/affine_rate_replication_results.md)
retain all outcomes. More complex activations have not earned promotion.

[Removing the learned affine correction after training](research/affine_activation_removal_results.md)
costs less than 0.020% NLL in every seed and preserves all quality gates.
Deployment copies use plain BlockShuffle and exact copied common weights.
This measures final-checkpoint dependence; it does not prove the training cause
or supply a new speed measurement.

Earlier **TinyStories** evidence also passes the local three-seed gates. The
[four-kernel inference study](research/fused_execution_results.md), on its seed 17
checkpoint, measures **1.206x throughput** versus equally compiled full SwiGLU
at batch 16 / context 128 BF16 on an RTX 4070 Laptop GPU. Inference allocation is
144.15 versus 169.08 MiB. This is full-sequence inference, not training or
autoregressive generation, and has not been remeasured on the WikiText weights.
The [additional validation](research/validation_tail_results.md) and
[projection conditioning study](research/joint_conditioning_results.md) retain
their specific scopes. Smaller-model and quadratic failures remain documented.

Both rational compiler variants failed complete training repeats despite passing
local derivative/memory checks. Keep the
[whole-product failure](research/activation_training_repeat_results.md) and
[correction-only failure](research/activation_correction_repeat_results.md)
separate from the native results. Start with the [current state](research/CURRENT_STATE.md)
for the complete evidence and remaining requirements.

The [published-architecture comparison](research/multihead_screen_results.md)
now includes both multi-head initialization controls. Both fail the local
200-step quality and memory gates. A simpler
[router-free headwise control](src/multihead_ffn/headwise.md) has exactly the
BlockShuffle budget: it saves 23.3% of the parallel model's training allocation
but still fails quality in the [completed screen](research/headwise_screen_results.md).
The full regression suite passes **248 tests**, with all 32 model signatures
preserved. The [full-suite record](results/verification/residual_geometry_tests_v1.json)
uses `-p no:anyio`; all assertions and GPU checks remain enabled. An
[explicitly qualified worker](results/long_duration_replication_v1/worker_transport_qualification_v1.json)
avoids plotting imports while calling the unchanged trainer. All eight new
trials finish; earlier native/import failures remain retained.

The new [interaction proof](research/headwise_hessian_obstruction.md) gives a
specific vector quadratic outside any single additive headwise FFN with square
learned mixers and arbitrary head-local functions. Full SwiGLU represents it
with 2*(d+1) hidden units; CPU forward/Hessian checks pass. This is a scoped
proof using established ideas, not a novelty or whole-network claim. An
overcomplete alternative matches the same parameter budget and is now tested below.

A new [overcomplete headwise module](src/multihead_ffn/overcomplete.md) now
represents that quadratic using the actual structured input and output factors,
with **70.3125% fewer FFN weights**. Its constructive FP64/Hessian checks,
three-seed initialization-scale checks and native BF16 qualification pass.
The [qualification report](research/overcomplete_qualification_results.md)
also records a **20.37% higher isolated forward/backward memory peak** than full
SwiGLU. It is now [integrated into the Transformer](research/overcomplete_integration_results.md),
with every older model signature preserved. Its eager full-model peak is
730.389 MiB, 10.647% above full GELU, so the memory gate fails by 4.270 MiB.
The [native gate-recomputation control](research/overcomplete_recompute_results.md)
reduces that peak to **680.014 MiB**, passing both full-control allowances.
Initial gradients, all 9.1 million final weights and the 20-step history match
eager in this qualification. The completed [language-quality screen](research/overcomplete_screen_results.md)
now fails: best-of-three-rate NLL **6.043891** is 2.305% above full SwiGLU,
2.800% above full GELU and 2.223% above calibrated narrow. Actual training peak
**676.931 MiB** passes memory; all updates remain finite. The scoped constructive
proof has not translated into competitive language learning. This recipe earns
no longer run at this budget; all rates and [trajectories](results/plots/overcomplete_screen.svg)
are retained. The completed [checkpoint diagnosis](research/residual_geometry_results.md)
finds real local scale effects but contradictory quality controls, so no
normalization repair is earned. A function-preserving rescaling changes raw
parameter-gradient norms by 8x with zero measured prediction change.
The distinct [additive block/global proposal](research/additive_block_lowrank_proposal.md)
retains full SwiGLU hidden width at the exact compressed budget; it is an
unimplemented known-family hypothesis, not a validated new primitive.

The [extended optimizer comparison](research/optimizer_bracket_results.md)
adds eight 800-step trials at two higher rates per recipe. All four still select
0.0012, retaining BlockShuffle's local quality/memory pass. The
[completed lower-rate check](research/optimizer_lower_results.md) adds three
controls and makes 0.0012 an interior winner for every recipe. The [longer replication](research/long_duration_replication_results.md) fails
the target despite that 800-step rate bracket. The [CPU optimizer diagnosis](research/duration_optimizer_geometry.md)
separates accumulated decay from actual trained norms; it does not prove a cause.

## Run

Use Python 3.12+, uv and a CUDA-compatible NVIDIA driver. The existing CUDA
13.2 PyTorch source is retained. Experiments use an RTX 4070 Laptop with 8 GiB
VRAM, BF16 where supported, and one GPU experiment at a time.

```powershell
uv sync --extra compile --extra data
uv run --extra compile --extra data python -m src.core.cli hardware
uv run --extra compile --extra data python -m src.core.cli train --config configs/wikitext2_blockshuffle_stronger_800.json --cache data/wikitext2_v1 --seed 17
uv run --extra compile --extra data pytest -q
uv run --extra compile --extra data python -m src.core.cli prepare --tokenizer results/data/tokenizer.json
uv run --extra compile --extra data python -m src.core.cli train --config configs/blockshuffle_70.json --seed 17
uv run --extra compile --extra data python -m src.core.cli train --variant swiglu --steps 800 --seed 17
uv run --extra compile --extra data python -m src.core.cli train --config configs/width_calibrated_70.json --seed 17
uv run --extra compile --extra data python -m src.core.cli report
uv run --extra compile --extra data python -m src.core.blockshuffle_report
uv run --extra compile --extra data python -m src.core.width_report
uv run --extra compile --extra data python -m src.core.quadratic_report
uv run --extra compile --extra data python -m src.core.scale_report
uv run --extra compile --extra data python -m src.core.compiler_report
uv run --extra compile --extra data python -m src.core.conditioning_report
uv run --extra compile --extra data python -m src.core.fused_report
uv run --extra compile --extra data python -m src.core.scale_replication_report
uv run --extra compile --extra data python -m src.core.validation_tail_report
uv run --extra compile --extra data python -m src.core.joint_conditioning_report
# Optional broader-data preparation; train-only tokenizer reconstruction
uv run --extra compile --extra data python -m src.core.wikitext_data --tokenizer results/data/wikitext2_tokenizer.json
```

Focused research reports use named run lists recorded in their source. New
CLI runs get unique timestamped directories; existing evidence is never overwritten.
Explicit CLI flags override JSON settings. Use `--device cpu --precision fp32`
for debugging. The [selected configuration](configs/blockshuffle_70.json)
includes the candidate's factor-specific learning rates and gate recomputation.
Dense controls include original and explicitly calibrated recipes; their
optimizer treatments are disclosed in the corresponding reports.

The [WikiText screen protocol](research/wikitext_screen_plan.md) uses a separately
verified corpus and equal new tuning budgets. Its official test split remains
unscored. `uv sync --extra data` installs the optional Parquet reader; this does
not change the CUDA PyTorch version.

For optional Windows compilation, `uv sync --extra compile` installs the pinned
triton-windows package while retaining the existing PyTorch version. Compiler
commands use `uv run --extra compile`; the completed probe and its native
first-attempt failure are documented in the report above.

## Architecture folders

| Folder | Architecture |
|---|---|
| [dense_ffn](src/dense_ffn/README.md) | Full and narrow GELU, ReLU, SiLU and SwiGLU references |
| [bezier_ffn](src/bezier_ffn/README.md) | Single quadratic curves, three-branch products and bounded cubic residuals |
| [grouped_ffn](src/grouped_ffn/README.md) | Grouped projections and channel shuffling |
| [shared_ffn](src/shared_ffn/README.md) | Dense FFNs reused across layers |
| [affine_shared_ffn](src/affine_shared_ffn/README.md) | Per-layer affine gates over a shared FFN |
| [cross_group_ffn](src/cross_group_ffn/README.md) | Fixed cross-group interaction |
| [adaptive_cross_group_ffn](src/adaptive_cross_group_ffn/README.md) | Learned coupling of projected values |
| [blockshuffle_ffn](src/blockshuffle_ffn/README.md) | Two shuffled block factors per projection |
| [paired_feature_ffn](src/paired_feature_ffn/README.md) | Signed and reciprocal feature pairs, with a duplicate control |
| [learnable_activation_ffn](src/learnable_activation_ffn/README.md) | Group-shared shifted Bezier, rational and affine residuals on both compressed bases |
| [multihead_ffn](src/multihead_ffn/README.md) | Parallel and router-free headwise SwiGLU; explicit initialization controls |

The numbered placeholders were renamed throughout active imports, tests and
documentation. All 15 original variants kept identical parameter and output
signatures. The [migration record](research/naming_migration.md) explains the
mapping; historical experiment provenance retains its original paths.

`src/core` owns the common decoder, data, trainer, evaluator and diagnostics.
Model folders contain architecture code and model notes. `research` contains
reasoning and results, `configs` records settings, and `tests` protects the
mathematics and experiment infrastructure. The original layout is preserved.

## Evidence and interpretation

- [Goal](doc/RESEARCH_GOAL.md), [rules](doc/RESEARCH_RULES.md) and
  [frozen initial protocol](research/experimental_plan.md).
- [Structural proofs](research/theory.md), [cross-group proof and experiments](research/interaction_report.md),
  [literature audit](research/literature.md) and [candidate ledger](research/idea_bank.md).
- [Initial screen](research/first_screen_report.md) and
  [earlier 800-step comparison](research/second_screen_report.md).
- [Paired-feature proof and negative screen](research/paired_feature_results.md).
- [Quadratic Bezier proof, ablations and negative screens](research/quadratic_bezier_results.md).
- [CUDA graph memory correction](research/graph_memory_correction.md); V2 audits
  supersede earlier stream-dependent memory comparisons.
- Raw metrics: `results/leaderboard.csv`, `results/experiments.jsonl`,
  `results/blockshuffle_summary.json`. Each run retains its history,
  configuration, source hashes/archive, checkpoint and diagnostic records.

Each corpus has its own frozen train-only tokenizer: a fixed TinyStories subset
or the pinned WikiText training split.
Validation NLL is comparable within this protocol; it is not comparable to
published models using different tokenizers. Current speed measurements are
full-sequence forward passes, including a separate fixed-shape CUDA graph audit.
They do not measure token-by-token generation. Weight sharing saves unique
parameters without reducing matrix arithmetic per invocation. Dense inference
caches also change compute and memory; both costs are reported explicitly.