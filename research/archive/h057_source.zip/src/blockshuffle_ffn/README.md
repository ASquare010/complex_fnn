# BlockShuffle SwiGLU

Verdict: **PROMISING as a compressed reference**. At 800 steps over three seeds,
this recipe beats the equally sized narrow SwiGLU in all seeds. Its mean NLL
is 3.10801 versus 3.16697 for narrow SwiGLU and 3.06714 for full SwiGLU.
It misses the 1% full-model quality limit and the factorized inference-speed
limit. This is an implementation of established structured projections;
architecture novelty is not claimed.

## Architecture and parameter accounting

Every projection replaces a dense matrix with

`W = inverse(P_out) B2 P_mid B1`, with `k = min(input_width, output_width)`.

B1 and B2 are block-diagonal matrices with G blocks; P denotes a fixed channel
permutation. A projection uses `k * (input_width + output_width) / G` weights.
The FFN computes `down(SiLU(up(x)) * gate(x))`. Each of the three projections
contains two factors. Features can interact across the original groups before
the scalar nonlinearity, unlike a single grouped projection.

| Setting, four layers at model width 192 | Hidden width | Groups | Unique FFN weights | Total weights | FFN reduction |
|---|---:|---:|---:|---:|---:|
| First structured screen | 832 | 8 | 294,912 | 1,672,896 | 75% |
| Selected three-seed recipe | 1,024 | 8 | 350,208 | 1,728,192 | 70.3125% |
| Full dense SwiGLU | 512 | 1 | 1,179,648 | 2,557,632 | 0% |

The selected candidate exactly matches narrow SwiGLU with hidden width 152 in
learned weights and FFN matrix FLOPs. Its hidden activations are wider and its
six grouped matrix operations add runtime overhead. Fewer matrix FLOPs did not
translate to higher measured speed on the tested laptop GPU.

## Initialization and optimization

Semi-orthogonal factors give the effective projection flat nonzero singular
values at initialization. Product gain is `0.02 * sqrt(max(input, output))`,
with the common residual-output scale. One factor is square orthogonal; the
other has orthonormal rows or columns, so permutations preserve this claim.
The average squared row norm matches the dense initialization. Training is
unconstrained: the final audited condition number reaches 646, so the initial
property is not a trained stability guarantee.

The selected recipe applies a factor LR multiplier
`input_width / (2 * factor_input_width)` and retains parameter-level AdamW
weight decay. Uniform learning rates failed the first screen. This optimizer
difference is an explicit part of the method. Native gate recomputation saves
only the gate inputs and recomputes SiLU during backward; it saves activation
memory without repeating projection GEMMs. Full training is not bitwise
identical to ordinary backward, although independent derivative checks pass.

## Execution and reproducibility

Use `uv run python -m src.core.cli train --config configs/blockshuffle_70.json`.
All non-FFN code remains in `src/core`. Separate serving utilities measure
factorized execution, packed gate factors, dense caches and CUDA graph replay.
Caches are additional buffers, not reductions in learned parameter count.

Read the [frozen derivation and sources](../../research/blockshuffle_plan.md),
[three-seed results](../../research/blockshuffle_results.md), and
[ablation and execution report](../../research/blockshuffle_progress.md).
Prior work includes [Wei et al.](https://arxiv.org/abs/2406.16450) and the
[factor learning-rate rule of Qiu et al.](https://arxiv.org/abs/2406.06248).
Our small-model protocol is not an exact reproduction of either paper.

## Optional execution research

The [four-kernel probe](../../research/fused_execution_plan.md) combines input
branches, gate arithmetic and permutation writes without changing learned
factors. It requires the optional UV compile extra and is inference-only.
The larger checkpoint passes trained accuracy and paired speed: compiled
fused/full throughput 1.206x, with NLL 2.772754 versus 2.775915. Read the
[completed result](../../research/fused_execution_results.md). Logical factorized FLOPs and padded tile arithmetic are disclosed
separately. Native training and historical results remain reproducible.

A separate [post-training conditioning intervention](../../research/conditioning_results.md)
reduces weak-direction imbalance in square down factors, with small NLL costs
in the measured checkpoints. It changes existing weights and is not silently
applied by the fused inference path. Rectangular projection spectra do not
prove full-network gradient stability.

The [joint floor and fused audit](../../research/joint_conditioning_results.md)
now passes on all three larger checkpoints: 190x to 1,136x lower worst down
condition, less than 0.011% combined NLL cost on either validation region,
with all full/narrow quality gates retained. This adjustment is optional and
adds no parameters. Its serving speed and training effect remain unmeasured.

## Stronger WikiText control after the activation study

At width 384 / layers 8,800 steps and peak LR 0.0012, the plain recipe reaches
4.759029 +/- .010381 mean validation NLL across seeds 17/29/43. It uses
2,801,664 FFN weights (70.3125% fewer than full), passes both full quality/memory
limits and beats calibrated narrow in every seed. The
[corrected report](../../research/affine_rate_replication_results.md) retains
all comparisons. [Configuration](../../configs/wikitext2_blockshuffle_stronger_800.json).

The affine activation's same-rate gain is only 0.101% with 2/3 wins, below its
material-promotion threshold. The earlier selected-rate advantage must not
be assigned to activation learning alone. This stronger optimizer setting does
not establish convergence, a novel architecture or WikiText serving speed;
the existing fused speed result uses an earlier TinyStories checkpoint.
