# Model notes

See [architecture and evidence](README.md).

## Longer-training limit

The [3,200-step replication](../../research/long_duration_replication_results.md)
fails the full target: mean NLL 4.147443 is 1.256% above full SwiGLU, and seed 43
also loses to calibrated narrow. All twelve compared runs are still improving
at the end. The shorter-budget success below does not establish convergence
or robust longer-training superiority.

## Stronger WikiText control after the activation study

At width 384 / layers 8,800 steps and peak LR 0.0012, the plain recipe reaches
4.759029 +/- .010381 mean validation NLL across seeds 17/29/43. It uses
2,801,664 FFN weights (70.3125% fewer than full), passes both full quality/memory
limits and beats calibrated narrow in every seed. The
[corrected report](../../research/affine_rate_replication_results.md) retains
all comparisons. [Configuration](../../configs/wikitext2_blockshuffle_stronger_800.json).

The affine activation's same-rate gain is only 0.101% with 2/3 wins, below its
material-promotion threshold. The earlier selected-rate advantage must not
be assigned to activation learning alone. This stronger optimizer setting does
not establish convergence, a novel architecture or WikiText serving speed;
the existing fused speed result uses an earlier TinyStories checkpoint.

## Isolated factor-decay outcome

The [longer product-decay control](../../research/duration_decay_results.md)
changes only existing factor decay coefficients. Seed-17 final NLL 4.152418 is
0.161% worse than parameter decay, and 1.145% above full SwiGLU. It fails the
local quality and material-gain gates; no additional tuning or seeds are earned.
Clipping rises from 30.50% to 42.41%. Fewer accumulated decay-only contractions
do not establish better optimization; all weights and recorded gradients remain
finite. Initial weights, LR multipliers, data and the 3,200-step budget match.
