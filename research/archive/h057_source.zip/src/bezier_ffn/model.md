# Model notes

See [architecture, configurations and verdicts](README.md), the
[quadratic equation and proofs](../../research/quadratic_bezier_plan.md),
[quadratic results](../../research/quadratic_bezier_results.md), and
[earlier cubic theory](../../research/theory.md).
