# Model notes

See [README.md](README.md) for equations, parameter counts and current verdict.
