# Dense FFN references

Hypothesis: conventional nonlinear projections establish quality and optimization
controls. Inspiration: standard Transformer FFNs and [SwiGLU](https://arxiv.org/abs/2002.05202).

Architecture: x -> up -> GELU/ReLU/SiLU -> down; SwiGLU multiplies SiLU(up(x))
by gate(x) before down. Bias-free. Parameters: 2dh or 3dh. Full h=4d for
ungated, h=8d/3 for SwiGLU. Narrow GELU h=d has 75% fewer FFN parameters.

Expected advantages: efficient GEMMs, well-understood training. Risks: a narrow
hidden width may remove useful nonlinear features. Common pre-norm residual
decoder is in ../core/transformer.py. All trainer/data logic is shared.

Experiment results: three-seed full GELU NLL 4.0846, SwiGLU 4.0850, narrow GELU 4.2160. Verdict: ACCEPTED as operational reference implementations, not as globally tuned SOTA.
At 800 steps, seed 17, full SwiGLU NLL 3.06505 outperforms full GELU 3.19312.
Keep both references; a narrow GELU match alone does not meet the research target.
Correctness and common training tests pass. These are short fixed-budget,
small-dataset controls, not globally tuned SOTA implementations.

The later three-seed 800-step comparison gives full SwiGLU NLL 3.067138 +/-
0.002325 and narrow SwiGLU hidden 152 NLL 3.166971 +/- 0.015172 (sample SD).
See [the structured comparison](../../research/blockshuffle_results.md).

## Stronger calibrated controls

The selected dense width recipe scales the initial down projection by
sqrt(h_reference/h), scales its LR by h_reference/h, and compensates its
AdamW decay so pure shrinkage is unchanged. It adds no inference operations.
At 800 steps, calibrated SwiGLU h152 has three-seed NLL 3.134833 +/- .007913,
improving on the original narrow recipe while remaining behind full SwiGLU.
Use `configs/width_calibrated_70.json`; the [ablation report](../../research/width_calibration_results.md)
separates initialization, LR and combined treatments.

Applying the same rule to GELU h228 gives NLL 4.100158 at 200 steps but
3.217538 at 800 steps, seed17. Its early advantage over calibrated SwiGLU
reverses at the longer budget. Use `configs/gelu_calibrated_70.json` to reproduce
this control; see the [quadratic follow-up](../../research/quadratic_bezier_results.md).
These baseline improvements must be accounted for before attributing gains to
new nonlinear features. They do not establish a novel FFN primitive.
