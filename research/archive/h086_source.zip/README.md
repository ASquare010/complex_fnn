# Parameter-efficient FFN research

**The research goal remains unmet.** The [progress overview](research/PROGRESS_OVERVIEW.md)
explains results, datasets, batch sizes, duration and learnable activations.

H085 completes 240 fresh runs and all independent score checks pass.
Learned offset changes selected aggregate held-out MSE by -13.149%
versus plain; offset with the fixed first-factor LR correction changes it by
-14.529%. Neither offset recipe earns full-model resource qualification. These fixed candidate recipes are closed.
The broad research goal remains unmet.
[Completed controlled offset study](research/latent_offset_fit_results.md).

The [affine mechanism study](research/latent_affine_mechanism_results.md)
separates gain and offset on all 12 selected checkpoints, without retraining.
Both affect predictions, but gain can be absorbed into existing factors. Folding
the affine operations preserves FP32 error within a relative 1.7e-8; runtime
benefit and a causal training advantage remain unestablished.

The [internal-activation fitting screen](research/latent_activation_recovery_results.md)
is complete: 192 runs, three seeds, all selection and selected held-out scores
independently reproduced. Tanh and sine curves lower error by 5.76% and 7.07%
versus plain, but the same-size affine control improves 15.03%. Both curves lose
to affine and narrow GELU, so neither earns a language trial. Local gradient
proofs remain valid within their scope; the full research target is unmet.

The [BLAST learning screen](research/blast_learning_screen_results.md) is complete:
24 fresh 200-update runs, nine passing preflight checks and 24 exact final
checkpoint rescores. BlockShuffle calibrated: fails fixed screen; BLAST SwiGLU: fails fixed screen; BLAST GELU: fails fixed screen.
These are short-budget results; the active model tree is unchanged.

**Latest longer-budget language result: matched-budget BlockShuffle GELU fails the fixed
3,200-step test.** The [H078 comparison](research/ungated_duration_results.md)
completes all six fresh seed-17 trials. The candidate reaches validation NLL
**4.242014**, with **70.3125% fewer FFN weights** and
**42.1700% fewer total model weights**. This fixed duration recipe is closed. Further training needs a distinct, justified hypothesis.

Candidate NLL differs by **+2.765%** versus full GELU,
**+3.327%** versus full SwiGLU,
**+0.860%** versus narrow GELU and
**+2.142%** versus narrow SwiGLU. Negative is better.
It exceeds both full-control NLL allowances and fails to beat either narrow control.

Its allocated peak is **280.0 MiB** and mean update time **104.3 ms**.
Versus plain BlockShuffle, candidate NLL changes by **+2.358%**
and mean update time by **-14.46%**. See the report for every control's
measured time and memory. Its updates also take longer than either full dense control.

This is one seed with rates fixed from the earlier short search. Late-plateau
diagnostics pass for **0/6** models; no convergence or replicated long-budget claim
follows. [H077](research/ungated_lm_replication_results.md) passes all three seeds
at 800 steps, but its small mean gain over plain wins only 1/3 seeds. Reused
development data and known building blocks do not establish state-of-the-art or
novelty. The failed same-width GELU recipe stays closed.

## Retained code

The active tree contains **three model folders, six variants and nine recipes**.
Discarded architectures, obsolete drivers and their tests are in the
[research archive](research/archive/README.md). Their results and checkpoints
are preserved. New experimental adapters remain beside their evidence until
qualified for active integration.

| Folder | Role | Current limitation |
|---|---|---|
| [dense_ffn](src/dense_ffn/README.md) | Full and narrow GELU/SwiGLU controls | Required for fair quality and resource comparisons |
| [blockshuffle_ffn](src/blockshuffle_ffn/README.md) | Structured operator and registered SwiGLU reference; existing ungated operator supports the GELU experiment | Plain SwiGLU misses the longer-training goal; GELU has the duration verdict above |
| [rational_blockshuffle_ffn](src/rational_blockshuffle_ffn/README.md) | Learned-activation research reference, adding 320 weights | One-seed quality potential, but native and tested memory repairs fail resource gates |

Shared training, evaluation, data and operators remain in `src/core`. Each active
model folder has an implementation, README and mathematical notes. The new GELU
configuration is isolated in the [duration artifacts](results/ungated_duration_v1/)
and is not a new registered variant or duplicated model folder.

Plain BlockShuffle's three-seed 3,200-step WikiText mean NLL is **4.147443**,
**1.256% above full SwiGLU**, exceeding the 1% allowance. All models still improve
at that endpoint. The GELU comparisons do not replace this
[longer-training failure](research/long_duration_replication_results.md).

## Run

Use Python 3.12+, UV and the existing CUDA environment. GPU experiments use one
RTX 4070 Laptop GPU with 8 GiB VRAM; keep experiments sequential and bounded.

```powershell
uv sync --extra compile --extra data
uv run --extra compile --extra data python -m src.core.cli hardware
uv run --extra compile --extra data python -m src.core.cli counts
uv run --extra compile --extra data python -m src.core.cli train --config configs/wikitext2_blockshuffle_stronger_800.json --cache data/wikitext2_v1 --seed 17
uv run --extra compile --extra data python -X faulthandler -m pytest -p no:anyio -q
```

The training command starts a new plain BlockShuffle reference run. It does not
repeat or overwrite completed evidence automatically. See
[configurations](configs/README.md) for the retained recipes and the
[frozen GELU replication plan](research/ungated_lm_replication_plan.md) for its isolated
setup. Retired variant names and failed rational compiler backends raise errors.

## Evidence and next steps

- [Current state](research/CURRENT_STATE.md): retained scope, latest decisions and
  what would earn further research.
- [Duration comparison](research/ungated_duration_results.md): six fresh 3,200-step
  trials, every endpoint, memory/time and late-loss changes. All six NLLs rescore exactly.
- [800-step replication](research/ungated_lm_replication_results.md): every seed,
  paired comparison and gate. All 18 final checkpoint NLLs rescore exactly.
- [Earlier language screen](research/ungated_lm_screen_results.md): all 21 rates
  that fixed the replication recipes; all saved NLLs independently verified.
- [GELU fitting](research/ungated_fit_results.md) and
  [resource qualification](research/ungated_resource_recovery_results.md):
  evidence that earned the language screen.
- [Learnable activation guide](research/learnable_activation_domain.md): adaptable
  shapes, parameter sharing, expressivity and gradient limitations.
- [Goal](doc/RESEARCH_GOAL.md), [rules](doc/RESEARCH_RULES.md) and
  [candidate ledger](research/idea_bank.md): hypotheses and negative results.
- [Cleanup record](research/cleanup_results.md) and
  [latest retirement](research/additive_retirement_results.md): archived branches
  and reproduction instructions.

The prior active suite passes **108 tests**; its source is unchanged. Five new
isolated integration checks and the independent language audit pass. All **171**
prior language/profile runs remain, with **45** new language trials kept separately: 21 H076, 18 H077 and six H078.
Proofs concern explicitly stated local functions. No result yet establishes
convergence, arbitrary-data superiority or a novel architecture.
