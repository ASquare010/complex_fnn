# Current research state

**The gold target remains unmet.** The active repository has been reduced to four
model folders, seven registered variants, nine recipe files and a shared core. The
[cleanup record](cleanup_results.md) documents removal of discarded branches; all
168 existing language-model/profile runs and their artifacts remain preserved.

## Retained candidates

| Candidate | Why keep it | What prevents promotion |
|---|---|---|
| Plain BlockShuffle | 70.3125% fewer FFN weights; replicated short-budget quality; useful structured execution | Three-seed 3,200-step mean NLL is 1.256% above full SwiGLU; loses to narrow on seed 43 |
| Rational BlockShuffle | Just 320 extra weights; one-seed 200-step NLL 5.898003 improves on the selected plain and narrow controls | Native training peak 883.17 MiB fails memory; no longer or multi-seed qualification |
| Additive block/low-rank | Exact compressed budget; constructive proof and three-seed synthetic memory qualification pass | Language quality untested; synthetic steps slower than dense |

Full and narrow GELU/SwiGLU remain active controls. None of the compressed models
is accepted as the completed research solution.

At 800 WikiText steps and matched peak LR 0.0012, plain BlockShuffle achieves
mean NLL 4.759029 across seeds 17/29/43. At 3,200 steps it reaches 4.147443 versus
full SwiGLU 4.095997. The longer experiment overrides the earlier optimistic
interpretation. All models continue improving at the final interval:
[800-step correction](affine_rate_replication_results.md),
[3,200-step replication](long_duration_replication_results.md).

Rational activation results are from a separate 200-step, one-seed learning-rate
screen; they cannot be ranked against those 800/3,200-step endpoints. Resetting its
learned shape changes NLL by only 0.0056%; final shape dependence is weak, and the
source of its training benefit is unresolved. Both attempted compiler backends
fail complete training fidelity despite local derivative checks:
[native activation results](learnable_activation_results.md),
[whole-product repeat](activation_training_repeat_results.md),
[correction-only repeat](activation_correction_repeat_results.md).
The rational branch is retained for a bounded memory/fidelity hypothesis only.

## Completed eliminations

Bezier and quadratic variants, grouped-only and coupled models, shared/affine-shared
FFNs, paired features, parallel/headwise/overcomplete FFNs, shifted learned
activations, narrow learned-activation variants and the affine activation branch
are archived. Some had useful local proofs or transient wins; none earned a place
in the active shortlist. The affine branch's matched-rate gain was only 0.101%,
with wins in 2/3 seeds, below its material-promotion gate.

The overcomplete candidate's best 200-step NLL is 6.043891: 2.305% above full SwiGLU,
2.800% above full GELU and 2.223% above calibrated narrow. Its memory passes after
native gate recomputation, but quality fails. The completed
[residual-geometry diagnosis](residual_geometry_results.md) finds scale effects and
contradictory quality controls. It does not justify another normalization repair.
Read the [archive](archive/README.md) for the full history and executable snapshot.

## Remaining work toward a defensible finish

1. Run a separately frozen balanced language screen for the
   [additive block/low-rank candidate](additive_block_lowrank_qualification_results.md).
   H060 passes17 numerical checks and the110-test integrated suite. All15 GPU
   workers complete20 synthetic updates; memory591.438MiB is7.03% below full GELU
   and14.01% below BlockShuffle, but20.67% above narrow. Dense controls remain faster.
   Initialization and update calibration are fixed; no language quality is established.
2. Earn longer runs through quality, memory and narrow-control gates. A useful
   candidate then needs at least three seeds, a credible convergence comparison,
   scaling evidence and broader-data/strong published controls.
3. Report matrix work, total-model weights, training memory, throughput and
   stability together. Prove only the mathematical statements the construction
   supports; establish novelty separately from recombining known factors.

The prior TinyStories four-kernel inference result is retained: 1.206x throughput
versus equally compiled full SwiGLU on one fixed checkpoint/shape. It is not a
training, autoregressive or WikiText speed claim. See
[fused execution](fused_execution_results.md) and
[conditioning](joint_conditioning_results.md).

## Verification after cleanup

The [current full suite](../results/verification/cleanup_tests_v1.json) passes
89 tests, with active sources unchanged during testing. Twelve exact before/after
cases cover all six variants on CPU FP32 and CUDA BF16, including two AdamW
updates and nonzero rational parameters. Synthetic trainer tests verify artifact
creation and checkpoint reloads. No new corpus training, validation ranking or
quality promotion was performed by this cleanup.

Historical frozen plans remain unchanged and are reproduced from the complete
[H057 source snapshot](archive/h057_source.zip), not against the reduced registry.

## H060 verification after integration

The [integrated suite](../results/additive_qualification_v1/process_integration_tests.json)
passes110 tests. All six previous CPU/GPU signatures remain exact. Three seeds
verify common non-FFN initialization and shared synthetic token streams across
five recipes. The qualification adds no corpus training or validation/test scoring.
See [the full result](additive_block_lowrank_qualification_results.md). H059's
cleanup evidence above is historical; the active shortlist now includes this one
new, explicitly experimental mechanism.
