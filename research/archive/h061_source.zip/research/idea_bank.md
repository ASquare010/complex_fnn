# Candidate ledger

Current allocation after H059: only full/narrow dense controls, plain BlockShuffle
and native rational BlockShuffle remain active. Earlier PROMISING/IMPLEMENTING
labels are historical and do not override [the current shortlist](CURRENT_STATE.md).
Discarded source and all results remain [archived](archive/README.md).

States and verdicts apply to the recorded setting, not an entire research family.

| ID | Question / decisive control | State |
|---|---|---|
| H001 | Shared bounded cubic versus narrow GELU, identical initialization | ELIMINATED from 200-step promotion; no credible three-seed gain |
| H002 | Eight curve groups versus one and narrow GELU | ELIMINATED in this setting; worse than narrow in 3/3 seeds |
| H003 | Does a static same-coordinate cubic bank expand the function class? | ELIMINATED as an expressivity claim by algebraic collapse |
| H004 | Distinct coordinates/intervals versus extra same-coordinate curves | IMPLEMENTED through H034; distinct coordinates, no LM promotion |
| H005 | Grouped wide projections versus equally sized narrow controls | ELIMINATED from the 200-step promotion screen |
| H006 | Reuse a full FFN across four existing layers | NEEDS_INVESTIGATION as a strong prior-art control; fails gold target at 800 steps |
| H007 | Compressed multiplicative interactions versus narrow SwiGLU | HYPOTHESIS, investigated through H008/H011 |
| H008 | Fixed cross-group input mixing restores missing products | ELIMINATED for LM promotion; constructive proof holds, additive toy control fails |
| H009 | Layer-specific affine scalar gates specialize shared SwiGLU | ELIMINATED from 800-step promotion; tiny NLL change with overhead |
| H010 | Spend the remaining parameter allowance on wider shared SwiGLU | ELIMINATED as a gold result; h608 still misses quality and costs more compute |
| H011 | Optional projected-value coupling preserves the original family | ELIMINATED for LM promotion; strict expressivity separation proved, toy optimization inconsistent |
| H012 | Two-factor structured projections mix features before nonlinearity | PROMISING compressed reference; factor-aware LR essential; quality and runtime gold gates unmet |
| H013 | Match AdamW shrinkage of the represented factored projection | ELIMINATED from promotion on seed 17; NLL 3.118254 versus 3.115322 |
| H014 | Spend the remaining parameter allowance on BlockShuffle width 1,024 | PROMISING; three-seed NLL 3.108014, beats matched narrow in 3/3 seeds; gold target unmet |
| H015 | Recompute only the SwiGLU gate during backward | VALIDATED for the measured memory reduction; complete training is not bitwise identical |
| H016 | Pack up/value factors to reduce matrix launches | ELIMINATED as a speed-gate solution; eager median 0.780 and corrected V2 graph 0.679 times dense |
| H017 | Apply CUDA graph replay equally to candidate and full reference | VALIDATED for fixed-shape correctness; factorized relative speed still fails the gate |
| H018 | Antipodal gates expose an exact bilinear feature with two dense projections | ELIMINATED from LM promotion; product fitting improves, but duplicate control has better NLL |
| H019 | Reciprocal products reuse both roles of each projected pair | ELIMINATED from LM promotion; fails matched GELU and duplicate controls |
| H020 | Duplicate features separate useful nonlinear diversity from redundant output weights | VALIDATED algebraic collapse; its better short-run NLL motivates an optimizer control |
| H021 | Calibrate dense FFN output variance and down-projection learning rate as width shrinks | VALIDATED as a stronger conventional control in three seeds; no architectural novelty |
| H022 | Direct bounded quadratic Bezier activation | ELIMINATED in tested direct/calibrated screens; loses to matched GELU |
| H023 | Three quadratic branches with learned pair products | ELIMINATED in tested screen; function gains did not transfer to LM |
| H024 | Shared/grouped quadratic correction of calibrated SwiGLU | ELIMINATED for promotion; only .095%/.061% gains over calibrated SwiGLU |
| H025 | Transfer locked compressed recipes to a trained model with doubled width and depth | VALIDATED for locked larger-model quality/memory in three seeds; fused serving passes on seed17, broader goal remains open |

| H026 | Apply default fullgraph compilation equally after training | ELIMINATED as the relative-speed solution; numerics pass, compiled candidate/full ratio .632 |
| H027 | Raise weak singular directions in square down factors after training | VALIDATED for post-training projection conditioning: .1 floor passes larger seed17 and all three smaller seeds; full orthogonalization loses quality |

| H028 | Fuse paired factors, activations and permutations into four inference kernels | VALIDATED for measured larger-checkpoint serving; compiled fused/full1.206x, fused/native1.780x, numerical/memory checks pass |

| H029 | Replicate the locked larger-model recipes in two additional seeds | VALIDATED locally; all three seeds pass both full-reference quality limits and beat calibrated narrow |
| H030 | Check previously unscored validation windows after model selection | VALIDATED within this corpus; all tail gates pass across three seeds, no second-corpus claim |

[Initial report](first_screen_report.md), [longer screen](second_screen_report.md),
[interaction proof and experiments](interaction_report.md),
[structured three-seed results](blockshuffle_results.md), and
[execution and ablations](blockshuffle_progress.md).
No mechanism above has verified novelty or met all research acceptance gates.
Preserve failures; compare stronger existing methods before expanding the search.

## H031: Combine the fixed condition floor and fused execution

**Status: VALIDATED locally.** All six original/floored larger-checkpoint cases pass numerical checks. The fixed floor improves worst down conditioning by 190x to 1,136x; combined prefix/tail NLL cost stays below 0.011%, with all baseline quality gates preserved. The [result](joint_conditioning_results.md) separates weight-intervention quality from kernel fidelity. An import-time native failure and explicit unchanged continuation are preserved. No training, new speed or whole-network stability claim.

## H032: Transfer under equal new tuning budgets to WikiText

**Status: ELIMINATED from 800-step promotion in this setting.** All twelve trials completed. Selected BlockShuffle NLL 5.970604 loses to calibrated narrow 5.912434, full SwiGLU 5.907694 and full GELU 5.879278; both 1% full-reference limits fail. Finite/memory gates pass. The [complete report](wikitext_screen_results.md) preserves all rates and boundary winners. The official test remains unscored.

## H033: Published multi-head FFN as a near-budget comparator

**Status: IMPLEMENTING.** The [standalone reference](archive/retired/src/multihead_ffn/README.md) follows the published architecture equations, retains normalization epsilon and has 350,976 weights per layer at the proposed small budget. CPU forward/gradient checks and a scoped routing-Jacobian upper bound are available. It now has registered normal/calibrated initialization controls under H045; it remains without a controlled LM result or flash kernel and does not establish a new primitive.

## H034: Learn shifted quadratic activation shapes on the compressed front-runners

**Status: ELIMINATED from the frozen promotion screen.** Both shifted-coordinate
variants lose to their selected base and fail memory. Distinct coordinates
implement H004 but do not establish a language-model gain. See [all twelve
activation trials](learnable_activation_results.md).

## H035: Learn a positive-denominator rational activation residual

**Status: PROMISING for quality, failed frozen memory promotion.** Rational
BlockShuffle NLL 5.898003 improves over its selected unchanged base by 1.216%
and calibrated narrow by 0.244%, passing both full-reference quality limits.
Only 320 weights are added across eight layers. Eager peak 883.17 MiB fails
memory. Narrow rational's 0.055% gain is too small for promotion. All four
selected reset interventions are complete; rational BlockShuffle's correction
can be zeroed with only 0.00562% NLL cost, so final shape complexity is not an
established explanation of its training gain. One seed, short budget, prior art.

## H036: Compile the rational activation/product to reduce training memory

**Status: VALIDATED for isolated memory; ELIMINATED as the current training backend.**
The [four-worker execution audit](activation_execution_results.md) reduces native
rational peak from 884.35 to 713.81 MiB and passes numerical gates. The [full
200-step repeat](activation_training_repeat_results.md) nevertheless degrades
NLL from 5.898003 to 6.011564 (+1.925%) while passing memory. Sampling RNG,
initial NLL, warmup parameters and the training-loop AST match. This supports
further numerical investigation, not longer training with this backend.

## H037: Is the rational gain mostly learned affine calibration?

**Status: PASSES the frozen short screen.** [Six trials](affine_activation_results.md)
select affine BlockShuffle at NLL 5.894765, 1.270% below its selected base and
0.055% below native rational, with just128 added weights. Native peak 718.08 MiB
passes both memory limits. Narrow affine loses. The rational affine-energy fit
is 96.388% on actual training-prefix inputs, versus 99.768% on the uniform grid.
Resetting the affine BlockShuffle correction costs only 0.001251% NLL. This
supports the simpler training recipe without proving a curvature-based cause,
independent replication, convergence or universal data adaptation.


## H038: Compile only the rational correction

**Status: PASSES the isolated execution audit.** Retain native SiLU and
gate-product backward while fusing the correction. The
[frozen diagnostic](activation_correction_execution_plan.md) tightens global
gradient fidelity to relative L2<=0.0001 before memory profiling. H036 remains
a failed full-training backend; a local pass does not supersede that result.
[H038 measured](activation_correction_execution_results.md) global gradient
relative L2 3.95e-8, exact sampled logits and717.31MiB peak. The qualified H040
[full-training repeat fails](activation_correction_repeat_results.md), so this
local numerical improvement is not sufficient training-fidelity evidence.


## H039: Does affine BlockShuffle retain its gain at 800 steps?

**Status: VALIDATED for its frozen one-seed gates.** All five 800-step trials
complete. Affine NLL 4.749982 improves 1.707% over selected plain BlockShuffle
and passes both full-reference quality/memory gates, earning H041. The
[report](affine_activation_longer_results.md) preserves the preflight accounting
failure and corrected, unchanged-computation launch.


## H040: Does correction-only fusion preserve the full training result?

**Status: FAILED full-training fidelity and quality gates.** The
[repeat](activation_correction_repeat_results.md) finishes at NLL 5.949104,
+0.8664% versus native rational, despite passing memory at 714.70 MiB.
Initial NLL, warmup parameters, optimizer groups, final sampling RNG and source
archives agree. The locally tiny derivative error did not preserve the measured
training trajectory. Both compiler boundaries remain unqualified for the
promoted longer native-architecture comparison.

## H041: Replicate the native affine recipe on WikiText

**Status: VALIDATED for the frozen three-seed comparison.** All ten new trials
complete; mean affine NLL 4.754207, 1.755% below selected plain BlockShuffle and
2.986% below full SwiGLU. Every gate passes in every seed. The
[report](affine_activation_replication_results.md) qualifies selected-seed
statistics, different recipe rates and slower descriptive training throughput.

## H042: Remove the learned activation after training

**Status: VALIDATED for all three frozen checkpoints.** Correction removal
costs .0058%-.0199% NLL, preserves every common weight and all quality gates.
The [deployment copies](affine_activation_removal_results.md) earn a separate
fused-inference audit. This is not a training-mechanism proof.

## H043: Complete the same-rate two-by-two control

**Status: FAILED two-rate robustness.** The [completed control](affine_activation_rate_control_results.md)
adds precisely plain LR .0012 and affine LR .0006 at 800 steps, seed17. It tests
the unresolved rate confound before gain/bias variants or corpus transfer.

At the same LR0.0012, affine helps only 0.0193% in seed 17; at LR 0.0006 it helps
0.337%, but both low-rate cells are worse than the high-rate cells. This qualifies
the larger H041 selected-rate advantage. Do not assign it to activation learning.

## H044: Replicate the stronger plain rate

**Status: COMPLETE; activation material-benefit gate FAILED, stronger plain control VALIDATED locally.** Two new seeds under the [frozen protocol](affine_rate_replication_plan.md)
complete the three-seed LR0.0012 plain/affine comparison. No model implementation
or other training setting changes. This corrective control takes precedence
over additional activation variants or transfer justified by H041's rate-confounded gain.

The [corrected result](affine_rate_replication_results.md) gives plain mean NLL
4.759029 and affine 4.754207. Affine helps only 0.101% and wins 2/3 seeds;
exploratory paired interval crosses zero. Plain retains 70.3125% FFN reduction
and passes every full/narrow quality/memory gate in every seed. H041 remains
a historical selected-recipe pass, with its activation-specific interpretation
qualified. Additional affine transfer/gain/bias variants are not promoted on
that confounded advantage. No GPU cohort remains running.

## H045: Qualify the published multi-head comparator

**Status: VALIDATED for CPU/GPU pipeline qualification only.** Two initialization controls are
registered without changing the 28 prior model snapshots. Gaussian output
scale is restored to 1.11925 times full SwiGLU by the explicit calibration.
Twelve focused tests and the 213-test full suite pass. Both GPU cases complete
at 832.10 MiB peak with finite/nonzero router gradients. The
[verified result](multihead_integration_results.md) earns a separately frozen
training screen. No validation/test data was scored, and no prior-art performance
or novelty conclusion follows yet.

## H046: Screen both multi-head initializations on validation

**Status: ELIMINATED for longer training at this local recipe.** The [frozen six-trial plan](multihead_screen_plan.md)
gives each initialization three rates and reports all same-rate controls.
The first baseline worker failed during PyTorch import before evaluation or
candidate training; a source-identical continuation uses multihead_screen_v2.
The failure and diagnosis remain archived. No partial measurement is reused.


H046 completed all six trials. Both initializations fail quality and memory
gates; calibrated best NLL 6.027381 versus narrow 5.912434, at 832.58 MiB.
See the [verified result](multihead_screen_results.md). No optimizer extension
or published-scale conclusion follows. H047 separately tested the simpler router-free
headwise control under its [frozen plan](headwise_screen_plan.md).

## H047: Exactly matched router-free headwise SwiGLU

**Status: ELIMINATED for longer training at this local recipe; memory component retained.**
The [verified result](headwise_screen_results.md) completes all three fixed rates.
Best NLL is 6.021328, 1.923% above full SwiGLU, 2.416% above full GELU and 1.842%
above narrow. Quality fails. At exactly 2,801,664 FFN weights, training peak is
638.37 MiB, 23.3% below parallel; both full-control memory gates pass.
All 30 older models remain exact. GPU qualification and all trials complete
without retries; the full suite passes 220 tests. Report generation had an
import-only failure followed by a recorded unchanged continuation.

Retain the [budget proof](multihead_budget_geometry.md) and
[fixed-coordinate interaction limit](archive/retired/src/multihead_ffn/headwise.md).
This changes head width and removes routing together; it is not an isolated
router or activation ablation. Both winners at the upper rate boundary remain
unbracketed. No extra rates, new activation shapes or longer run is promoted.
The next evidence priority is equal-budget optimizer/convergence testing for
the stronger plain model and full/narrow controls. No GPU cohort is running.


## H048: Equal extended global-rate search at 800 steps

**Status: VALIDATED for the local selected-recipe gates; lower boundary remains open.**
The [verified result](optimizer_bracket_results.md) completes all eight new
800-step trials without retries or numerical failures. All four recipes retain
LR 0.0012. Plain NLL 4.750900 is 2.653% below full SwiGLU, 2.320% below full GELU
and 2.933% below calibrated narrow. All fixed quality/memory gates pass. At the
same LR 0.0048, plain loses to narrow; the effect is not rate-independent.

All 223 tests pass and 30 prior model snapshots remain exact. The
[decay-only accounting](optimizer_rate_geometry.md) quantifies how global rate
changes the represented-map contraction; it does not prove the cause of the NLL
change. No architectural novelty or convergence follows. A separately frozen
lower-rate check is next; existing independent seeds for unchanged selected
recipes remain historical evidence and need no redundant retraining.


## H049: Close the lower boundary at 800 steps

**Status: VALIDATED for the local four-rate gates; convergence remains open.**
The [verified result](optimizer_lower_results.md) completes all three missing
0.0006 dense-control cells without retries or numerical failures. The sixteen-cell
grid retains 0.0012 for every recipe, now an interior grid point. Plain remains
2.653% below full SwiGLU, 2.320% below full GELU and 2.933% below narrow at seed 17,
with 70.3125% FFN reduction and all memory gates passing. All 225 tests pass.

This is a discrete rate bracket in one seed, not a global optimum or convergence
claim. Existing independent seeds for unchanged recipes need no redundant reruns.
The next requirement is a separately frozen longer-budget comparison with all
full and calibrated narrow controls. No GPU cohort is running.


## H050: Four-times-longer fixed-recipe comparison

**Status: VALIDATED for local final-step gates; longer robustness and convergence NEED INVESTIGATION.**
The [verified result](long_duration_results.md) completes all four 3,200-step
runs without retries or numerical failures. Plain retains 70.3125% FFN reduction
and all local quality/memory gates, but its NLL is 0.9819% above full SwiGLU,
0.4323% above full GELU and only 0.1763% below calibrated narrow. The separate
>=0.2% narrow margin fails. All models improve by another 2.2%-2.8% in the last
800 steps and fail the late-plateau diagnostic. The 800-step advantage therefore
cannot be promoted to converged superiority.

Every source/checkpoint/data/sampler contract verifies. The final suite passes
227 tests with `-p no:anyio`; an earlier optional compiler crash and a separate
plugin-import crash remain documented. No NN or trainer code changed.
Independent-seed longer controls are the next frozen comparison; duration-specific
rate ranking, broader scale and novelty remain open.


## H051: Independent longer-duration seeds

**Status: FAILED longer-duration all-seed promotion; parameter/memory components retained.**
The [verified replication](long_duration_replication_results.md) adds eight
3,200-step trials at seeds 29/43 and retains four seed-17 controls. Mean plain
NLL is 4.147443, 1.256% above full SwiGLU, 0.637% above full GELU and only
0.146% below narrow. Seed 43 exceeds the 1% full-SwiGLU allowance and loses to
narrow. The primary rule fails; a mean cannot rescue a failed seed. Every model
continues improving and fails the late-plateau screen.

All twelve source/data/checkpoint/sampler contracts verify. Two pre-training
import failures are retained; the qualified minimal worker completes all eight
new trials, changing only startup dispatch and no NN computation. All 233 tests
pass. Figure regeneration later hit additional import-only failures, retained
separately; isolated Matplotlib plotting without Torch imports completed the
consistent-color figure from verified records. The earlier 800-step result remains duration-qualified. A separately
frozen optimizer investigation precedes promotion; no GPU cohort is running.


Analytical follow-up only: [structured headwise mixers](structured_headwise_budget.md)
would reallocate the same 2,801,664 FFN weights from dense mixers to larger
private nonlinear subnetworks. Counts and bounded-input Jacobian upper bounds
are derived, with no registered architecture, new LM score or novelty claim.
This did not alter the frozen H051 protocol.


H051 operational record: two pre-training import failures are retained. The
qualified minimal worker avoids report imports, uses the identical frozen
configurations and calls the unchanged trainer. Two sampler reconstructions
and four tamper/overwrite checks pass; all eight actual trials subsequently completed.
The [CPU duration diagnosis](duration_optimizer_geometry.md) adds no optimizer
updates or validation scores and does not change the cohort.


The [Hessian witness](headwise_hessian_obstruction.md) rules out an explicit
vector quadratic for any single square-mixer additive headwise module, despite
arbitrary learned head functions. Full SwiGLU has an explicit representation;
CPU construction/Hessian checks pass. The argument uses established function
decoupling ideas and is not claimed novel. The derived overcomplete alternative
has the same FFN budget but remains unimplemented and untrained.

## H052 - Longer-duration product-decay control (ELIMINATED from promotion)

The frozen [single-variable control](duration_decay_plan.md) completes one
seed-17, 3,200-step WikiText trial (6,553,600 new tokens). Only existing factor
decay changes; four H050 references are retained. [Final NLL 4.152418](duration_decay_results.md)
is 0.161% worse than parameter-decay BlockShuffle and 1.145% above full SwiGLU.
Both local full-SwiGLU quality and the >=0.2% material-gain gate fail. No
independent seeds or further decay tuning are earned. Prior H013 negative
results and H051's longer-training failure remain.

Clipping rises from 30.50% to 42.41%; allocation remains 714.12 MiB. The initial
losses, exact source/data/sampler, changed optimizer coefficients, finite
weights/layers/gradients and checkpoint are verified. An interim advantage at
800/1600/2400 steps reverses by 3200; the full trajectory is retained. The last
interval still improves by 2.439%, failing the late-plateau diagnostic.

All 235 tests pass; all 31 registered models and the trainer/optimizer/data
implementations stay unchanged. The minimal worker completes on its first
attempt, without numerical or native/process failures. This rejects one
mechanistic optimizer ablation, not all factor regularization or headwise
alternatives. The untrained overcomplete proposal still requires constructive
representation and calibration checks before any new LM budget.

## H053 - Overcomplete structured-headwise qualification (VALIDATED locally)

The [frozen qualification](overcomplete_qualification_plan.md) passes for the
standalone 384->512->384 module, G=16, H=8, head width 64, private hidden 200.
It uses exactly 350,208 weights/layer. An explicit construction represents the
three-output quadratic excluded by square-mixer additive headwise layers,
using the actual structured A/B factors. FP64 forward error 1.718e-16 and
maximum Hessian-vector error 3.740e-14 support the checked construction.

The [model notes](archive/retired/src/multihead_ffn/overcomplete.md) derive rectangular
covariance accounting and isometric A / scaled row-isometric B initialization.
Three-seed Gaussian RMS ratios to full SwiGLU are 1.01356/1.01821/1.01643.
BF16 forward and maximum gradient errors are .007889/.008171; ten fixed
synthetic-target updates stay finite. All 238 tests pass. No language training
or scoring occurs and no new Transformer variant is registered.

Isolated eager forward/backward allocation is 69.366 versus 57.626 MiB for
full SwiGLU (+20.37%). Full-model integration/memory must therefore precede
any language-training allocation. This is a scoped expressivity/numerical
qualification, not a novelty, family-containment, easy-learning, convergence
or quality result. It earns only separately frozen integration and memory
checks; prior headwise, activation and decay failures remain.

## H054 - Complete-Transformer integration (VALIDATED); eager memory FAIL

The [frozen integration](overcomplete_integration_results.md) preserves all 31
older weights/logits/losses/gradients/FLOPs and registers a 32nd variant. Each
layer exactly matches its standalone calibrated initialization. All 241 tests
pass. Three fresh 20-update fixed-batch qualifications use 122,880 repeated
training-token exposures and zero validation targets.

Native candidate peak 730.389 MiB is 3.347% above full SwiGLU 706.733 MiB and
10.647% above full GELU 660.108 MiB. It misses the latter allowance by 4.270 MiB
and does not earn a quality screen. All weights/gradients/moments/layers stay
finite and checkpoint logits restore exactly. The small memory-only failure
justifies a separately frozen test of the existing native gate recomputation,
not extra activation or routing complexity. H054 itself adds no recomputation.

## H055 - Native overcomplete gate recomputation (VALIDATED locally)

The [frozen execution ablation](overcomplete_recompute_results.md) passes.
Peak 680.014 MiB is 50.375 MiB / 6.897% below eager; relative costs are -3.781%
versus full SwiGLU and +3.016% versus full GELU. Both memory limits and the
70.3125% FFN-weight reduction pass. No parameter, function, initialization,
LR/decay policy, new activation or router is added. The existing native
SwiGLU backward is reused, opt-in through the shared trainer helper.

All 32 default model signatures remain exact; 243 tests pass. Full-model initial
loss and every BF16 parameter gradient match eager, and all 9,099,648 final
weight elements plus the entire 20-step history are bitwise equal in these
runs. This is a local execution result, not a universal precision guarantee.
One new cell adds 40,960 repeated training-token exposures and zero validation
targets. It earns a separately frozen balanced quality screen; H054's eager
failure and the broader unmet research target remain.

## H056 - Overcomplete headwise quality screen (ELIMINATED at this budget)

The [frozen three-rate screen](overcomplete_screen_results.md) completes all
three seed-17 200-step trials. NLL .0003/.0006/.0012 is
6.303587 / 6.134152 / **6.043891**. The selected boundary rate loses full SwiGLU
by **2.305%**, full GELU by **2.800%**, narrow by **2.223%**, selected plain
BlockShuffle by 1.227% and square headwise by .375%. All original quality gates
fail; parameter and actual 676.931 MiB memory gates pass. No longer training,
activation repair or automatic rate search is earned.

All updates and final weights/moments/layer outputs remain finite; clipping is
42% / 20% / 7%. All 245 tests pass and existing model/training computation is
unchanged. The three new cells use 1,228,800 sampled targets and score all
322,688 validation targets per evaluation; official test remains unscored.
A diagnosed pre-training diagnostic-source assertion failure and its exact
source are retained. The corrected preflight verifies old/current diagnostic
values, fifteen retained control artifacts, actual groups and exact sampler
states. All GPU cells complete first attempt.

Reusable component: H053's explicit quadratic construction survives as a scoped
representation result. Rejected inference: that escaping this headwise
obstruction with matched initialization RMS suffices for better short-budget
language learning. The selected candidate's layer-0 FFN output RMS grows to
13.7203 (full SwiGLU 3.8765), while later FFN parameter-gradient norms are smaller.
A separate residual-scale/factor-geometry checkpoint diagnosis is justified;
these measurements do not prove a causal explanation or justify automatic repair.

## H057 - Residual geometry diagnosis (VALIDATED locally); causal remedy unproven

The [frozen diagnosis](residual_geometry_results.md) matches all 340 local norm
VJPs to an independent finite-epsilon formula, maximum relative error 9.882e-8.
Native candidate/control later gain ratios are .7071 SwiGLU, .7742 narrow,
1.0368 GELU, .1711 BlockShuffle and .4113 square headwise; CPU ordering agrees.
Full GELU is a counterexample to a simple larger-gain/better-quality story.
Candidate lower rates have larger gains and better B conditioning but worse NLL.
The diagnosis does not establish the cause of the quality deficit or earn a fix.

A disposable exact value/down rescaling changes corresponding gradient norms
by 1/8 and 8, with zero measured logit/loss/predicted-gradient error. All weights
are restored and checkpoints unchanged. Initial isometry is lost during training;
selected B-map conditions span 129.26-3978.29 while numerical rank stays 384.
These observations do not prove whole-network vanishing or optimization failure.

All 248 tests pass; 14 CPU and six BF16 probes plus one gauge check make zero
optimizer updates and score no validation/test targets. All phases complete
first attempt, with all old computation/configurations retained. Stop this
analysis branch; no activation, normalization or optimizer repair is earned.

## H058 - Additive block/global SwiGLU (HYPOTHESIS; unimplemented)

The [proposal](additive_block_lowrank_proposal.md) uses W=S+LR in all three
ordinary SwiGLU projections: G=8 block support, d=384, h=1024 and rank48.
Its count is exactly 350,208 weights/layer, or 70.3125% below full FFN, matching
all current compressed controls while retaining full hidden width. A direct
block path and additive global path are distinct from private headwise networks.
An explicit quadratic construction is described, but no implementation or
numerical qualification has occurred and no training budget is frozen.

Sparse-plus-low-rank pretraining and diagonal additions are established prior
art, including SLTrain (2024), low-rank passthrough networks (2016) and DLoR
expressivity work (2026). This is not a verified novel combination. Next: audit
primary implementation conventions, derive fixed calibration/optimizer geometry,
implement independently verified structured execution, and earn actual full-model
memory before balanced language training. Alternative dense self-guidance and
H057-inspired optimizer repairs are deferred; do not revive the failed recipe.

## H059 - Finish the active shortlist (VALIDATED as repository cleanup)

The [cleanup](cleanup_results.md) reduces 11 model folders/32 variants to three
folders/six variants. Nine old folders and 138 obsolete individual files moved to
a verified archive. The reusable grouped operator remains in core; rational
BlockShuffle now has its own descriptive folder. No new LM trial or quality
promotion occurred. All 89 active tests pass and all six retained variants match
pre-cleanup CPU/GPU weight, prediction, gradient and update signatures exactly.
Plain inference adapters reject learned activations atomically, preventing silent
shape removal. H058 remains the next unimplemented hypothesis; no failed branch
is revived by this housekeeping result.

## H060 - Additive block/low-rank qualification (VALIDATED locally)

The [fixed policy](additive_block_lowrank_qualification_results.md) passes17 local
checks and the full110-test suite. The actual model preserves70.3125% FFN weight
reduction; the vector quadratic is represented using actual supported tensors.
All15 synthetic GPU workers finish20 updates with finite weights/moments. Candidate
allocation591.438MiB is7.03% below full GELU and14.01% below BlockShuffle, but20.67%
above narrow. Its median step78.814ms remains slower than both dense controls.
All six previous CPU/GPU model signatures are exact. The mechanism earns a balanced
language screen, not a quality/novelty/convergence claim. The initialization and
update calibration were frozen before scoring and will not be retuned after it.

## H061 - Additive block/low-rank quality screen (ELIMINATED at this budget)

The [three-rate screen](additive_block_lowrank_screen_results.md) completes all
three seed-17, 200-step cells. NLL at .0003/.0006/.0012 is
6.243238 / 6.093809 / **6.032030**. The boundary winner loses to full SwiGLU by
**2.105%**, full GELU by **2.598%**, narrow by **2.023%** and selected BlockShuffle
by **1.029%**. Every original quality gate fails; 70.3125% FFN reduction and
617.806 MiB actual training allocation pass. It loses to all four controls at
each matched rate too. No longer training or automatic repair is earned.

All weights, moments and diagnostics remain finite; clipping is 54.5% / 31% / 10%.
The three cells add 1,228,800 sampled targets; official test remains unscored.
113 tests pass. A filename-collision preflight failure is preserved and repaired
before training, with no model or protocol change. The corrected preflight
matches twelve full-size controls to four archived source trees, verifies target
order and final sampler states, and all new training cells finish first attempt.
H060's construction and numerical qualification survive as scoped evidence;
competitive language learning does not follow. Retire this tested recipe.
