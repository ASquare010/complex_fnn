# Shared experiment code

Only the FFN factory changes the architecture. Shared decoder, data, training,
evaluation, optimizer setup and reproducibility code remain here.

| Files | Responsibility |
|---|---|
| `config.py`, `transformer.py` | Six active variants, exact parameter accounting and shared decoder |
| `trainer.py`, `optimization.py` | One training loop, explicit calibration/decay groups, gate recomputation |
| `data.py`, `wikitext_data.py` | Frozen token caches, verified manifests, deterministic sampling and target coverage |
| `benchmark.py`, `diagnostics.py`, `model_audit.py` | Loss evaluation, timing, gradients and scoped projection diagnostics |
| `structured_linear.py` | Reusable grouped linear map and channel shuffle; not a standalone candidate |
| `reproducibility.py`, `frozen_train_worker.py` | Source/config snapshots and qualified immutable cell execution |
| `cli.py`, `report.py`, `analysis.py` | Run commands and cohort-aware historical summaries |
| `serving.py`, `graph_serving.py`, `compile_serving.py`, `fused_serving.py`, `conditioning.py` | Retained post-training execution controls and numerical tools |

Execution tools contain explicit scope checks. Plain packed/fused adapters do not
support learned activations. Dense caches consume extra buffers. These tools do
not establish new training speed or quality findings simply by being available.

Completed one-off experiment drivers live in the [archive](../../research/archive/README.md).
Reproduce their frozen source rather than adding discarded variants back to the
active factory. See [current state](../../research/CURRENT_STATE.md) for allocation.
