# Rational BlockShuffle SwiGLU

**Secondary candidate: promising one-seed quality, memory gate failed.** This is
plain BlockShuffle with a small learned residual added to its SiLU gate. Only the
native implementation remains active.

`phi(z) = SiLU(z) + 0.25*(a0 + a1*z + a2*z^2 + a3*z^3)/(1 + beta*z^2)`

Coefficients are bounded by tanh and shared within each channel group. Each layer
learns its own shape. At eight groups and eight layers, the activation adds just
320 weights: 2,801,984 FFN weights and 9,099,968 total, a 70.3091% FFN reduction.

The selected one-seed 200-step WikiText trial reaches NLL 5.898003, 1.216% below
its selected plain control and 0.244% below calibrated narrow. Its training peak
is **883.17 MiB**, failing memory. These are short-screen results, not a replicated
advantage. Resetting the final learned shape changes NLL by only 0.0056%:
[all screen outcomes](../../research/learnable_activation_results.md).

Use [the retained recipe](../../configs/wikitext2_blockshuffle_rational_screen.json)
with `--learning-rate 0.0012` for the selected screen rate. The file retains its
original 0.0006 template default. Checkpoint gate recomputation is supported.
The rejected compiler backends and affine/shifted activation branches are
[archived](../../research/archive/README.md). Plain packed/fused SwiGLU adapters
reject this model because they do not evaluate its learned activation.

Read [the mathematical notes](model.md) and the
[activation domain guide](../../research/learnable_activation_domain.md).
