# Retained experiment recipes

These nine JSON files retain their original bytes. They are starting configurations,
not a claim that every default learning rate is the selected winner. CLI flags
explicitly override their settings.

| Corpus | Retained recipes | Cache |
|---|---|---|
| TinyStories | `scale384_full_gelu_800.json`, `scale384_full_swiglu_800.json`, `scale384_calibrated_narrow_800.json`, `scale384_blockshuffle_800.json` | `data/tinystories_v1` |
| WikiText-2 | `wikitext2_full_gelu_800.json`, `wikitext2_full_swiglu_800.json`, `wikitext2_calibrated_narrow_800.json`, `wikitext2_blockshuffle_stronger_800.json` | `data/wikitext2_v1` |
| WikiText-2, rational activation screen | `wikitext2_blockshuffle_rational_screen.json` | `data/wikitext2_v1` |

The retained plain WikiText candidate uses the matched 800-step rate 0.0012.
For that matched-rate comparison, pass `--learning-rate 0.0012` to each full/narrow
control too. The rational screen template has rate 0.0006; its selected 200-step
trial used `--learning-rate 0.0012`. That trial fails memory and has not earned a
longer allocation. Do not compare its 200-step NLL directly with 800-step runs.

```powershell
uv run --extra compile --extra data python -m src.core.cli train --config configs/wikitext2_full_swiglu_800.json --cache data/wikitext2_v1 --learning-rate 0.0012 --seed 17
uv run --extra compile --extra data python -m src.core.cli train --config configs/wikitext2_blockshuffle_rational_screen.json --cache data/wikitext2_v1 --learning-rate 0.0012 --seed 17
```

Every command starts a new run. See [current evidence](../research/CURRENT_STATE.md)
before allocating compute. Historical grids and discarded recipes are in the
[archive](../research/archive/README.md); reproduce frozen historical experiments
using their complete source snapshot.
