# Parameter-efficient FFN research

The active code now contains **three compressed candidates and four dense controls**.
Discarded architectures, obsolete experiment drivers and their tests have moved to
[the research archive](research/archive/README.md). Existing results and checkpoints
are preserved.

| Active folder | Role | Evidence and decision |
|---|---|---|
| [dense_ffn](src/dense_ffn/README.md) | Full and narrow GELU/SwiGLU controls | Required to measure quality and parameter efficiency |
| [blockshuffle_ffn](src/blockshuffle_ffn/README.md) | Main compressed reference | 70.3125% fewer FFN weights; good short-budget results, longer-training target still fails |
| [rational_blockshuffle_ffn](src/rational_blockshuffle_ffn/README.md) | Secondary learned-activation candidate | Adds 320 weights; promising one-seed quality, excessive training memory |
| [additive_block_lowrank_ffn](src/additive_block_lowrank_ffn/README.md) | Newly qualified experimental candidate | Same compressed budget; synthetic memory passes, language quality untested |

**The research goal is not yet achieved.** In the three-seed 3,200-step WikiText
comparison, plain BlockShuffle reaches mean NLL **4.147443**, **1.256% above full
SwiGLU**, exceeding the 1% allowance. All models are still improving at the endpoint.
See the [longer-training results](research/long_duration_replication_results.md).
A short-budget win or a constructive representation proof does not establish a
breakthrough, convergence, or superiority on arbitrary data.

The [current state](research/CURRENT_STATE.md) gives the remaining work. The
[additive block/low-rank proposal](research/additive_block_lowrank_proposal.md) is
now passes [H060 numerical and synthetic resource qualification](research/additive_block_lowrank_qualification_results.md). Its language quality and novelty are unproven. Failed branches will not receive further tuning without new evidence.

## Run

Use Python 3.12+, UV, and the existing CUDA environment. GPU experiments use one
RTX 4070 Laptop GPU with 8 GiB VRAM; keep experiments sequential and bounded.

```powershell
uv sync --extra compile --extra data
uv run --extra compile --extra data python -m src.core.cli hardware
uv run --extra compile --extra data python -m src.core.cli counts
uv run --extra compile --extra data python -m src.core.cli train --config configs/wikitext2_blockshuffle_stronger_800.json --cache data/wikitext2_v1 --seed 17
uv run --extra compile --extra data python -X faulthandler -m pytest -p no:anyio -q
```

The training command creates a new run; it does not reproduce or overwrite a
completed run automatically. See [configurations](configs/README.md) for controls,
corpus selection and the rational candidate's selected learning rate. Retired
variant names and the two failed rational compiler backends now raise clear errors.

## Read and navigate

- [Goal](doc/RESEARCH_GOAL.md) and [research rules](doc/RESEARCH_RULES.md).
- [Learnable activation guide](research/learnable_activation_domain.md): what can
  adapt, parameter sharing, expressivity, and gradient limitations.
- [Candidate ledger](research/idea_bank.md): all hypotheses and negative results.
- [Cleanup record](research/cleanup_results.md): retained scope and verification.
- [Archive and reproduction instructions](research/archive/README.md).

Shared training, evaluation, data and reusable operators remain in `src/core`.
Each active model folder contains its implementation, README and mathematical notes.
The current suite passes **110 tests**. All six previously retained variants match their
pre-cleanup CPU FP32 and CUDA BF16 signatures, including gradients and optimizer
updates. Plain-only inference adapters reject learned activations instead of
silently dropping them. H060 measures 591.438 MiB synthetic training allocation, 14.01% below BlockShuffle,
with slower steps than dense controls. It adds no language-quality result.
